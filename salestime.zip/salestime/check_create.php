<?php
include("./config.php");

$acc = $_POST['acc'];
$pwd = $_POST['pwd'];
$un = $_POST['username'];
$name = $_POST['name'];
$phone  = $_POST['phone'];
$sql_check_phone = "SELECT * FROM `users` WHERE `phone` = '$phone'";
$pid = $_POST['pid'];
$sql_check_pid = "SELECT * FROM `users` WHERE `id` = '$pid'";
$mail = $_POST['mail'];
$sql_check_mail = "SELECT * FROM `users` WHERE `id` = '$mail'";



$ret_arr =  array();

if ($_POST) {
    $num1 = mysqli_num_rows(mysqli_query($link, $sql_check_phone));
    $num2 = mysqli_num_rows(mysqli_query($link, $sql_check_pid));
    $num3 = mysqli_num_rows(mysqli_query($link, $sql_check_mail));
    if ($_POST['name'] == NULL or $_POST['phone'] == NULL or $_POST['pid'] == NULL or $_POST['mail'] == NULL) {
        $status = 0;
        $text = "尚有資料未填寫完成"; 
    }elseif($num1 == 1){
        $status = 1;
        $text = "手機號碼已被使用或輸入錯誤";
    } elseif($num2 == 1){
        $status = 2;
        $text = "身分證已被使用或輸入錯誤";
    }elseif($num3){
        $status = 3;
        $text = "電子郵箱已被使用或輸入錯誤";
    }else {
        $status = 4;
        $text = "成功新增帳號，請重新登入";    
        $sql = "INSERT INTO `users`(`account`, `password`, `username`, `name`, `phone`, `mail`, `id`)VALUES ('$acc','$pwd','$un','$name','$phone','$mail','$pid')";
        $result = mysqli_query($link, $sql);
       
    }

    $ret_arr[] = array("status" => $status, "text" => $text);
    echo json_encode($ret_arr);
}