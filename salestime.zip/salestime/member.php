<!DOCTYPE html>
<?php
session_start();
include("config.php");

if(@$_SESSION["loggedin"] == true){
  
}else{
  echo "<script>alert('請先登入會員');</script>";
  $url = 'login.php'; 
  echo "<script language = 'javascript' type = 'text/javascript'>"; 
  echo " window.location.href = '$url'"; 
  echo "</script>"; 
}

?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+TC:wght@300&display=swap" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/10094612fa.js"></script>
    <title>小賣時光－最懂你／妳的寶物交易網</title>
</head>
<body>
    <header>
      <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
          <div class="container-fluid">
            <a class="navbar-brand" href="home.php">
                <img id="logo" src="img/logo_4.png">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                  <a class="nav-link active" aria-current="page">
                      <div>
                          <select name="select_box" class="form-select text-left" id="select_box">
                              <option>選擇遊戲</option>
                              <option>新楓之谷</option>
                              <option>APEX</option>
                              <option>英雄聯盟</option>
                          </select>
                      </div>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link">
                      <select class="form-select text-left">
                          <option>選擇伺服器</option>
                          <option>雪吉拉</option>
                          <option>菇菇寶貝</option>
                          <option>三眼章魚</option>
                      </select>
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link">
                      <input id="search_width" class="search-txt text-left" type="text" name="" placeholder="請輸入道具名稱">
                  </a>
                </li>
                <li class="nav-item">
                  <a type="button" class="btn-head" href="index.php"><p>搜尋</p></a>
                </li>
              </ul>
              <ul class="navbar-nav me-auto mb-2 mb-lg-0" id="icon_start">
                  <li class="d-flex nav-item icon_head">
                      <a href="userlove.php">
                          <i class="fa-solid fa-heart icon_head"></i>
                      </a>
                      <a href="member.php">
                        <i class="fa-solid fa-user icon_head"></i>
                    </a>
                    <a href="warecar.php">
                        <i class="fa-solid fa-cart-shopping icon_head"></i>
                    </a>
                      <a href="#">
                          <i class="fa-solid fa-comment-dots icon_head"></i>
                      </a>
                  </li>
              </ul>
            </div>
          </div>
        </nav>
      </div>
      
    </header>
    <section id="member-first">
      <div class="container">
        <div class="row">
          <div class="col-md-3" id="menu-left">
            <div class="accordion" id="accordionExample">
              <div class="card">
                <div class="card-header" id="headingOne">
                  <h2 class="mb-0">    
                    <a class="btn btn-link" data-toggle="collapse" href="#collapseOne" role="button" aria-expanded="false" aria-controls="collapseOne">
                      <h5>我是買家</h5>
                    </a>
                  </h2>
                </div>
            
                <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
                  <div class="card-body">
                    <a href="warecar.php"><p>我的專屬</p></a>
                    <a href="warecar.php"><p>我的訂單</p></a>
                    <a href="warecar.php"><p>折價券</p></a>
                    <a href="warecar.php"><p>收購中的商品</p></a>
                  </div>
                </div>
              </div>
              <div class="card">
                <div class="card-header" id="headingTwo">
                  <h2 class="mb-0">
                    <a class="btn btn-link" data-toggle="collapse" href="#collapseTwo" role="button" aria-expanded="false" aria-controls="collapseTwo">
                      <h5>我是賣家</h5>
                    </a>
                  </h2>
                </div>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                  <div class="card-body">
                    <a href="warecar.php"><p>我的專屬</p></a>
                    <a href="warecar.php"><p>我的訂單</p></a>
                    <a href="warecar.php"><p>折價券</p></a>
                    <a href="warecar.php"><p>收購中的商品</p></a>
                  </div>
                </div>
              </div>
              <div class="card">
                <div class="card-header" id="headingThree">
                  <h2 class="mb-0">
                    <a class="btn btn-link" data-toggle="collapse" href="#collapseThree" role="button" aria-expanded="false" aria-controls="collapseThree">
                      <h5>會員資料</h5>
                    </a>
                  </h2>
                </div>
                <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                  <div class="card-body">
                    <a href="warecar.php"><p>我的專屬</p></a>
                    <a href="warecar.php"><p>我的訂單</p></a>
                    <a href="warecar.php"><p>折價券</p></a>
                    <a href="warecar.php"><p>收購中的商品</p></a>             
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <div id="member" class="col-md-9" >
            <div class="container">
              <div id="about-user" class="row">
                <div id="user-data" class="col-md-3">
                  <div class="text-center">
                    <img id="user-img" src="img/user/user1.jpg">
                    <h4>阿軒</h4>
                    <p>信用評價:100分</p>
                  </div> 
                </div>
                <div id="account-data" class="col-md-6">
                  <h3>我的帳戶(No.1234567)</h3>
                  <hr>
                    <div class="container">
                      <div class="row">
                        <div class="col-md-6">
                          <h4>10元</h4>
                          <p>帳戶餘額</p>
                        </div>
                        <div class="col-md-6">
                          <h4>10</h4>
                          <p>我的粉絲</p>
                        </div>
                      </div>
                      <a href="#"><p>提款</p></a>
                    </div>
                </div>

                <div id="user-love" class="col-md-3">
                  <h3>我的關注</h3>
                  <hr>
                  <div class="container">
                    <div class="row">
                      <div class="col-md-6">
                        <a href="#">
                          <h4>10</h4>
                          <p>追蹤中</p>
                        </a>
                      </div>
                      <div class="col-md-6">
                        <a href="#">
                          <h4>10</h4>
                          <p>足跡</p>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div id="about-item" class="row">
                <div id="buyer-data" class="col-md-6">
                  <h3>我是買家</h3>
                  <hr>
                  <div class="container">
                    <div class="row">
                      <div class="col-md-4 text-center">
                        <a href="#">
                          <i class="fa-regular fa-gem"></i>
                          <h4>我的專屬</h4>
                        </a>
                      </div>
                      <div class="col-md-4 text-center">
                        <a href="#">
                          <i class="fa-solid fa-wallet"></i>
                          <h4>待付款</h4>
                        </a>
                      </div>
                      <div class="col-md-4 text-center">
                        <a href="#">
                          <i class="fa-solid fa-clipboard-check"></i>
                          <h4>已完成</h4>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
                <div id="seller-data" class="col-md-6">
                  <h3>我是賣家</h3>
                  <hr>
                  <div class="container">
                    <div class="row">
                      <div class="col-md-4 text-center">
                        <a href="#">
                          <i class="fa-solid fa-store"></i>
                          <h4>賣場管理</h4>
                        </a>
                      </div>
                      <div class="col-md-4 text-center">
                        <a href="#">
                          <i class="fa-solid fa-box-archive"></i>
                          <h4>待移交</h4>
                        </a>
                      </div>
                      <div class="col-md-4 text-center">
                        <a href="#">
                          <i class="fa-solid fa-clipboard-check"></i>
                          <h4>已完成</h4>
                        </a>
                      </div>
                    </div>
                  </div>           
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
      


    <footer id="foot-one">
        <div class="container">
          <div class="row">
            <div class="col-md-3 text-center">
              <h5 class="fw-bold">新手上路</h5>
              <p><a href="#">免費註冊</a></p>
              <p><a href="#">交易流程</a></p>
              <p><a href="#">付款方式</a></p>
            </div>
            <div class="col-md-3 text-center">
              <h5 class="fw-bold">售後服務</h5>
              <p><a href="#">交易申訴</a></p>
              <p><a href="#">申請取消交易</a></p>
              <p><a href="#">提款相關</a></p>
            </div>
            <div class="col-md-3 text-center">
              <h5 class="fw-bold">客戶服務</h5>
              <p>客服電話：(02) 5579-8591</p>
              <p>服務時間：週一至週五10:00-21:00</p>
              <p>例行維護：每日4:30-5:00</p>
            </div>
            <div class="col-md-3 text-center">
              <h5 class="fw-bold">常用入口</h5>
              <p><a href="#">帳號切結書下載</a></p>
              <p><a href="#">留言諮詢</a></p>
              <p><a href="#">客服信箱</a></p>
            </div>
          </div>
        </div>
      </footer>
  
      <button type="button" class="btn btn-danger btn-floating btn-lg back-to-top" id="btn-back-to-top">
        <i class="fa-solid fa-arrow-up"></i>
      </button>
  
      <script src="js/test.js"></script>
  </body>
  </html>