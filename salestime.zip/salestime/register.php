<?php

include("./config.php");

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://code.jquery.com/jquery-3.5.0.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Serif+TC:wght@600&display=swap" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    <link rel="icon" href="愛之味.ico">
    <link href="css/login-style.css" rel="stylesheet">
    <title>小賣時光－最懂你／妳的寶物交易網</title>
</head>

<style>
    .accordion-button {
        color: #8ea604;
        font-weight: bolder;
    }

    #f1 {
        color: #7A7A7A;
    }

    #f2 {
        color: #7A7A7A;
    }
</style>


<body>

<header>
    <div class="container">
        <div class="container-fluid">
            <div class="row justify-content-between">
                <div class="col-md-2">
                    <a href="home.php">
                        <img id="logo" src="img/logo_4.png">
                    </a>
                </div>
                <div class="col-md-3" id="back-home">
                    <a href="home.php" >
                        <i class="fa fa-home">回首頁</i>
                    </a>
                </div>
            </div>
        </div>
    </div>  
</header>

<section id="first">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6" id="register-window">
                <div class="row justify-content-center">
                    <div class="col-lg-12 text-center" id="register-title">
                        <h3 class="fw-bold">請填寫註冊資料</h3>
                    </div>
                </div>

                <div class="row justify-content-center">    
                    <div class="col-md-10" id="register-form-window">
                        <!-- 表單 -->
                        <div class="accordion" id="accordionExample">
                            <!-- Block 1 -->
                            <!-- 隱藏警告資訊 -->
                            <div class="row justify-content-center">
                                <div class="col-10 alert text-center" role="alert" style="display: none;" id="messege">

                                </div>
                            </div>                            
                            
                            <div class="accordion-item ">
                                <h2 class="accordion-header" id="headingOne">
                                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                        登入資料
                                    </button>
                                </h2>
                                <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne"  data-bs-parent="#accordionExample">
                                    <!-- 登入資料 -->
                                    <div class="accordion-body">
                                        <form id="f1">
                                            <div class="form-floating" id="unbox">
                                                <input type="text" class="form-control" id="username" name="username" placeholder="text">
                                                <label for="username" class="form-label">使用者名稱</label>
                                            </div>

                                            <div class="form-floating" id="accbox">
                                                <input type="text" class="form-control" id="acc" name="acc" placeholder="text">
                                                <label for="acc" class="form-label">帳號</label>
                                            </div>

                                            <div class="form-floating" id="pwdbox">
                                                <input type="password" class="form-control" id="pwd" name="pwd" placeholder="password">
                                                <label for="pwd" class="form-label">密碼</label>

                                            </div>

                                            <div class="form-floating" id="pwd_checkbox">
                                                <input type="password" class="form-control" id="pwd_check" name="pwd_check" placeholder="password">
                                                <label for="pwd_check" class="form-label">確認密碼</label>
                                            </div>
                                            <div class="row justify-content-center">
                                                <button type="button" class="btn col-4" id="next"><p class="fw-bold">下一步</p></button>
                                            </div>    
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Block 2 -->
                            <div class="row justify-content-center">
                                <div class="col-10 alert text-center" role="alert" style="display: none;" id="messege">

                                </div>
                            </div>   

                            <div class="accordion-item">
                                <h2 class="accordion-header" id="headingTwo">
                                    <button class="accordion-button collapsed" type="button" disabled="disabled" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                        個人資料
                                    </button>
                                </h2>
                                <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
                                    <div class="accordion-body">
                                        <form id="f2">
                                            <div class="form-floating" id="namebox">
                                                <input type="text" class="form-control" id="name" name="name" placeholder="text">
                                                <label for="realname" class="form-label">真實姓名</label>
                                            </div>
                                            <div class="form-floating" id="phonebox">
                                                <input type="tel" class="form-control" id="phone" name="phone" placeholder="text">
                                                <label for="phone" class="form-label">電話號碼</label>
                                            </div>
                                            <div class="form-floating" id="IDbox">
                                                <input type="text" class="form-control" id="pid" name="pid" placeholder="text">
                                                <label for="pid" class="form-label">身分證</label>
                                            </div>
                                            <div class="form-floating" id="mailbox">
                                                <input type="email" class="form-control" id="mail" name="mail" placeholder="text">
                                                <label for="mail" class="form-label">E-mail</label>
                                            </div>
                                            <div class="row justify-content-center">
                                                <button type="button" class="btn col-4" id="create"><p class="fw-bold">建立帳號</p></button>
                                            </div> 
                                            
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>  
    </div>
</section>
    

<section id="third">
    <div class="row container-fluid">
        <div id="title" class="col-md-12 text-center">
            <img src="img/logo_1.png">
        </div>
    </div>
</section>

<footer id="foot-one">
      <div class="container">
        <div class="row">
          <div class="col-md-3 text-center">
            <h5 class="fw-bold">新手上路</h5>
            <p><a href="#">免費註冊</a></p>
            <p><a href="#">交易流程</a></p>
            <p><a href="#">付款方式</a></p>
          </div>
          <div class="col-md-3 text-center">
            <h5 class="fw-bold">售後服務</h5>
            <p><a href="#">交易申訴</a></p>
            <p><a href="#">申請取消交易</a></p>
            <p><a href="#">提款相關</a></p>
          </div>
          <div class="col-md-3 text-center">
            <h5 class="fw-bold">客戶服務</h5>
            <p>客服電話：(02) 5579-8591</p>
            <p>服務時間：週一至週五10:00-21:00</p>
            <p>例行維護：每日4:30-5:00</p>
          </div>
          <div class="col-md-3 text-center">
            <h5 class="fw-bold">常用入口</h5>
            <p><a href="#">帳號切結書下載</a></p>
            <p><a href="#">留言諮詢</a></p>
            <p><a href="#">客服信箱</a></p>
          </div>
        </div>
      </div>
    </footer>


</body>

</html>


<script>
    // ---提示輸入---
    $(document).ready(function() {
        $("#username").on("click", function() {
            $(".hint_text").remove();
            $("#unbox").append("<span class='form-text mx-2 hint_text'>請輸入10字元內中文或英文名稱</span>");
        })
        $("#acc").on("click", function() {
            $(".hint_text").remove();
            $("#accbox").append("<span class='form-text mx-2 hint_text'>請輸入10字元內的字母、數字組合</span>");
        })
        $("#pwd").on("click", function() {
            $(".hint_text").remove();
            $("#pwdbox").append("<span class='form-text mx-2 hint_text'>建議輸入8字元以上的字母、數字組合，20字元為限</span>");
        })
        $("#pwd_check").on("click", function() {
            $(".hint_text").remove();
            $("#pwd_checkbox").append("<span class='form-text mx-2 hint_text'>請再次輸入密碼</span>");
        })
        //個人資料
        $("#name").on("click", function() {
            $(".hint_text").remove();
            $("#namebox").append("<span class='form-text mx-2 hint_text'>請輸入您的真實姓名</span>");
        })
        $("#phone").on("click", function() {
            $(".hint_text").remove();
            $("#phonebox").append("<span class='form-text mx-2 hint_text'>請輸入您的手機號碼</span>");
        })
        $("#pid").on("click", function() {
            $(".hint_text").remove();
            $("#IDbox").append("<span class='form-text mx-2 hint_text'>請輸入您的身分證號碼，方便驗證</span>");
        })
        $("#mail").on("click", function() {
            $(".hint_text").remove();
            $("#mailbox").append("<span class='form-text mx-2 hint_text'>請輸入您的電子郵件</span>");
        })
        // ---名稱是否使用---
        $("#username").keyup(function() {
            var uname = $("#username")
            $.ajax({
                url: "./check_uname.php",
                type: "POST",
                data: uname,
                success: function(status) {
                    if (status == 1) {
                        $(".hint_text").remove();
                        $("#unbox").append("<span class='form-text mx-2 hint_text' style='color:red';'>使用者名稱重複，請重新輸入</span>");
                    }
                    if (status == 0) {
                        $(".hint_text").remove();
                        $("#unbox").append("<span class='form-text mx-2 hint_text' style='color:green';>使用者名稱未重複</span>");
                    }
                },
                error: function(xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText
                    alert('Error - ' + errorMessage);
                }
            })
        })
        // ---帳號是否使用---
        $("#acc").keyup(function() {
            var acc = $("#acc")
            $.ajax({
                url: "./check_acc.php",
                type: "POST",
                data: acc,
                success: function(status) {
                    if (status == 1) {
                        $(".hint_text").remove();
                        $("#accbox").append("<span class='form-text mx-2 hint_text' style='color:red;'>帳號已使用，請重新輸入</span>");
                    }
                    if (status == 0) {
                        $(".hint_text").remove();
                        $("#accbox").append("<span class='form-text mx-2 hint_text' style='color:green;'>帳號可使用</span>");
                    }
                },
                error: function(xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText
                    alert('Error - ' + errorMessage);
                }
            })
        })
        // ---密碼重複輸入正確---
        $("#pwd_check").keyup(function() {
            var p1 = $("#pwd");
            var p2 = $("#pwd_check");
            if (p1.val() != p2.val()) {
                $(".hint_text").remove();
                $("#pwd_checkbox").append("<span class='form-text mx-2 hint_text' style='color:red;'>與原先密碼不符，請重新輸入</span>");
            } else {
                $(".hint_text").remove();
            }
        })
        // 開啟第二段輸入區
        $("#next").on("click", function() {
            var mes = $("#messege");
            $.ajax({
                url: "./check_final.php",
                type: "POST",
                dataType: "JSON",
                data: $("#f1").serialize(),
                success: function(response) {
                    mes.css("display", "block");
                    if (response[0].status == "4") {
                        mes.removeClass("alert-danger").addClass("alert-primary").html(response[0].text);
                        $("#collapseTwo").addClass("show");
                        $("#collapseOne").removeClass("show");
                        $("#collapseOne").addClass("hide");
                    } else {
                        mes.addClass("alert-danger").html(response[0].text);
                        console.log(response[0].text)
                    }
                },
                error: function(xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText
                    alert('Error - ' + errorMessage);
                }
            })
        })
        //有無輸入名稱
        $("#name").keyup(function() {
            var name = $("#name")
            $.ajax({
                url: "./check_name.php",
                type: "POST",
                data: name,
                success: function(status) {
                    if (status == 1) {
                        $(".hint_text").remove();
                        $("#namebox").append("<span class='form-text mx-2 hint_text' style='color:red';'>尚未填寫真實姓名</span>");
                    }else{
                        $(".hint_text").remove();
                        $("#namebox").append("<span class='form-text mx-2 hint_text' style='color:green';'>已填寫真實姓名</span>");
                    }
                },
                error: function(xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText
                    alert('Error - ' + errorMessage);
                }
            })
        })
        // ---手機是否使用---
        $("#phone").keyup(function() {
            var phone = $("#phone")
            $.ajax({
                url: "./check_phone.php",
                type: "POST",
                data: phone,
                success: function(status) {
                    if (status == 1) {
                        $(".hint_text").remove();
                        $("#phonebox").append("<span class='form-text mx-2 hint_text' style='color:red;'>手機號碼已被使用，請重新輸入</span>");
                    }
                    if (status == 0) {
                        $(".hint_text").remove();
                        $("#phonebox").append("<span class='form-text mx-2 hint_text' style='color:green;'>此手機號碼可使用</span>");
                    }
                },
                error: function(xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText
                    alert('Error - ' + errorMessage);
                }
            })
        })
        // ---身分證輸入正確---
        $("#pid").keyup(function() {
            var pid = $("#pid")
            $.ajax({
                url: "./check_pid.php",
                type: "POST",
                data: pid,
                success: function(status) {
                    if (status == 1) {
                        $(".hint_text").remove();
                        $("#IDbox").append("<span class='form-text mx-2 hint_text' style='color:red;'>身分證已被使用，請重新輸入</span>");
                    }
                    if (status == 0) {
                        $(".hint_text").remove();
                        $("#IDbox").append("<span class='form-text mx-2 hint_text' style='color:green;'>此身分證可使用</span>");
                    }
                },
                error: function(xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText
                    alert('Error - ' + errorMessage);
                }
            })
        })
        //電子郵箱輸入
        $("#mail").keyup(function() {
            var mail = $("#mail")
            $.ajax({
                url: "./check_mail.php",
                type: "POST",
                data: mail,
                success: function(status) {
                    if (status == 1) {
                        $(".hint_text").remove();
                        $("#mailbox").append("<span class='form-text mx-2 hint_text' style='color:red;'>電子郵箱已被使用，請重新輸入</span>");
                    }
                    if (status == 0) {
                        $(".hint_text").remove();
                        $("#mailbox").append("<span class='form-text mx-2 hint_text' style='color:green;'>此電子郵箱可使用</span>");
                    }
                },
                error: function(xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText
                    alert('Error - ' + errorMessage);
                }
            })
        })

        $("#create").on("click", function() {
            var mes = $("#messege");
            $.ajax({
                url: "./check_create.php",
                type: "POST",
                dataType: "JSON",
                data: $("#f2").serialize() + '&' + $("#f1").serialize(),
                success: function(response) {
                    mes.css("display", "block");
                    if (response[0].status == "4") {
                        alert(response[0].text);
                        document.location.replace("./login.php") //無法回到建立帳號頁面
                    } else {
                        mes.addClass("alert-danger").html(response[0].text);
                        console.log(response[0].text)
                    }
                },
                error: function(xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText
                    alert('Error - ' + errorMessage);
                }
            })
        })
    })
</script>